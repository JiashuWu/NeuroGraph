/** Automatically generated file. DO NOT MODIFY */
package org.developerfeed.ankita.mypaintbrush;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}